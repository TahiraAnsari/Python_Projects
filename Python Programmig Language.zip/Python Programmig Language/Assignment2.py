# 2: Write a program that takes three numbers from the user and prints the
#greatest number.
# Input the 1st number: 25
# Input the 2nd number: 78
# Input the 3rd number: 87
# Expected Output
# The Greatest: 87

num_First = int(input('Enter the First Number:'))
num_Second = int(input('Enter the Second Number:'))
num_Third = int(input('Enter the Third Number:'))
if num_First > num_Second:
    if num_First > num_Third:
        print('The Greatest number is:',num_First)
    else:
        print('The Greatest number is:',num_Third)
else:
    if num_Second > num_Third:
        print('The Greatest number is:',num_Second)
    else:
        print('The Greatest number is:',num_Third)
        
