condition=input("Press A to contninue: ")
while(condition=="A"):
    condition = input("Press A to contninue: ")
print("Exited")
