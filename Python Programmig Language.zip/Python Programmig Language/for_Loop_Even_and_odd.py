number=int(input("Enter range: "))
for index in range(1, number+1):
    if index%2==0:
        print(index, "even")
    else:
        print(index," odd")
