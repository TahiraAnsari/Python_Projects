month =input("Enter month name: ")

if month=="december" or month=="january" or month=="febuary":
    print("Month name: ",month)
    print("Season is winter")
elif month=="march" or month=="april" or month=="may":
    print("Month name: ",month)
    print("Season is Spring")
elif month=="june" or month=="july" or month=="august":
    print("Month name: ",month)
    print("Season is Summer")
elif month=="sepetmber" or month=="october" or month=="november":
    print("Month name: ",month)
    print("Season is Autumn")
else:
    print("Invalid month name")
