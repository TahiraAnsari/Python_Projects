# Write a Python program that takes a number from the user and generates an integer
# between 1 and 7. It displays the weekday name.
# Test Data
# Input number is 3
# Expected Ouput:
# Wdnesday

day = int(input('Enter a number:'))
match day:
    case 1:
        print('Monday')
    case 2:
        print('Tuesday')
    case 3:
        print('Wednesday')
    case 4:
        print('Thrusday')
    case 5:
        print('Friday')
    case 6:
        print('Saturday')
    case 7:
        print('Sunday')
    case _:
        print('wrong input! Please enter a number between 1 to 7')
