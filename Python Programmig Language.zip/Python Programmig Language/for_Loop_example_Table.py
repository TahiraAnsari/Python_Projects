table =int(input("Enter any table number: "))
table_range=int(input("Enter table range: "))
for a in range(1,table_range+1):
    print(table," x ", a , " = ",table*a)





