
lang=input("Enter any language name: ")

match lang:
    case "python":
        print("Python is script type programming")
    case "javascript":
        print("Javascript is document object")
    case "html":
        print("Html is a markup language")
    case _:
        print(lang," language is defined in out module")
