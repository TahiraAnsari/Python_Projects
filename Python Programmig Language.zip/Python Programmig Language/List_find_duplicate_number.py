# write python program to find duplicate values from list
# List = [10,20,10,2,5,4,3,10]

list1 = [10,20,10,2,5,4,3,10]
list2 = []

for i in list1:
    if i not in list2:
        list2.append(i)
        print(list2)
    else:
        print(i)


