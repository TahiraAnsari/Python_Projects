# Assignment: 09
# 1*
# **2
# 3***
# 4****
# *****5

# even and odd condition 

for i in range(1, 6):
        if i % 2 != 0:
            print(i,'*' * i)
        else:
            print('*' * i,i)



