def menu():
    print("Student Management System")
    print("Main Menu/Functions")
    print('1 View Student Record')
    print("2 Update Student Record")
    print("3 Add New Student Record")
    print("4 Delete Student Record")
    print("5 Exit System")
    option=input('Select any option: ')
    if option=='1':
        view()
    elif option=='2':
        update()
def exit_system():
    print("Thank You Using Our System")
    print("System Exited")
    exit(0)

def view():
    print("View Student Record")
    roll_no=input("Enter Student Roll No")
    if roll_no==data[2]:
        print(data)
        choice=input("Do you want to continue press 1 no press 0")
        if choice=='1':
            menu()
        else:
            exit_system()
    else:
        print('Invalid Roll No')


def update():
    print("Update Student Record")
    roll_no = input("Enter Student Roll No")
    if roll_no == data[2]:
        print(data)
        name =input("Enter Student New Name: ")
        data[0]=name
        print("Student Updated Record")
        print(data)
        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            menu()
        else:
            exit_system()
    else:
        print('Invalid Roll No')

data =["ALi",'20000','20','IT','USindh','ali@gmail.com']
option=0
choice=0
menu()
