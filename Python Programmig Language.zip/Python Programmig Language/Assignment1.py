# 1: Write a Python program to get a number from the user and print whether it is
#positive or negative.
# Test Data
# Input number: 35
# Expected Output:
# Number is positive
num = int(input('Enter a Number:'))
if num >= 0:
    if num == 0:
        print('Number is Zero:',num)
    else:
        print('Number is Positive:',num)
else:
    print('Number is Negative:',num)
