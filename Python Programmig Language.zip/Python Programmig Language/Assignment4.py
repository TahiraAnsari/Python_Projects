# 4: Write a python program that takes a year from the user and prints weather it
# is a leap or not.
# Test Data
# Input the Year: 2016
# Expected Ouput:
# 2016 is a leap year

lp_Year = int(input('Enter Year:'))
if lp_Year % 4 == 0:
    print(lp_Year,'is a Leap Year')
else:
    print(lp_Year,'is not a Leap Year')
