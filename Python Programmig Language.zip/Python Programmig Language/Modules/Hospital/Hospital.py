
import Patient
import Doctors

Hospital1 = {'Name':'Agha Khan Hospital','Charges':200000, 'Room_no':110}
Hospital2 = {'Name':'Jeejal Maa','Charges':12000}
Hospital3 = {'Name':'PPHI','Charges':'Free of Cost'}
Hospital4 = {'Name':'LUMHS','Charges':'Free of Cost'}
Hospital5 = {'Name':'Civil Hospital','Charges':'Free of Cost'}

print('Hospital Mangement System')
print('\n Patient Detail \n')
print('Patient Name:',Patient.Patient1['Name'])
print('Patient age:',Patient.Patient1['Age'])
print('Patient Blood group:',Patient.Patient1['Blood'])
print('Patient Doctor Name:', Doctors.Doctor1['Name'])
print('Doctor Speciality:', Doctors.Doctor1['Speciality'])
print('Room_no:',Hospital1['Room_no'])
print('Hospital Name:',Hospital1['Name'])
