Doctor1 = {'Name':'Dr.Pashmina', 'Salary':1200000, 'Speciality':'Dermatalogist'}
Doctor2 = {'Name':'Dr.Ghulam Nabi', 'Salary':1000000, 'Speciality':'Dentist'}
Doctor3 = {'Name':'Dr.Sara', 'Salary':12300000, 'Speciality':'Urologist'}
Doctor4 = {'Name':'Dr.Abdullah', 'Hospital':'LMHS', 'Salary':14200000, 'Speciality':'Neurologist'}
Doctor5 = {'Name':'Dr.Marvi', 'Salary':1100000, 'Speciality':'Opthalmologist'}
