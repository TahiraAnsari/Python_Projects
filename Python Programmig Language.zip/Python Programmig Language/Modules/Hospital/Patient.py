Patient1 = {'Name':'Ali Ahmed', 'Age':23, 'Gender':'Male', 'Blood':'A+'}
Patient2 = {'Name':'Rabia Memon', 'Age':30, 'Gender':'Female', 'Blood':'O-'}
Patient3 = {'Name':'M.Hussain', 'Age':33, 'Gender':'Male', 'Blood':'B+'}
Patient4 = {'Name':'Ghulam ALi', 'Age':20, 'Gender':'Male', 'Blood':'AB+'}
Patient5 = {'Name':'Zeenat', 'Age':26, 'Gender':'Female', 'Blood':'A-'}
