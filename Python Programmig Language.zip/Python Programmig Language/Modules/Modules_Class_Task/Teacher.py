teacher1={'name':'Sir Ahmed','subject':'Web Technology'}
teacher2={'name':'Asad Ali','subject':'Data Sciecne'}
