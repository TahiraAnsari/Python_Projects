department1={'name':'BSIT'}
department2={'name':'BSSWE'}
department3={'name':'BSCS'}
department4={'name':'BSCE'}
