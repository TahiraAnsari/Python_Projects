import University
import Departments
import Teacher

student1={'name':'Siraj Ahmed','Roll No':'2k22/10','Fees':19000,'age':21}
student2={'name':'Awais Ahmed','Roll No':'2k22/09','Fees':21000,'age':20}

print("Student Name: ",student1['name'])
print("Student ROll No: ",student1['Roll No'])

if student1['Fees']>=20000:
    print("Student Fees: ", student1['Fees'])
    print("Discount: ",2000)
    print("Final Fees: ",student1['Fees']-2000)
    print("Student age: ",student1['age'])
    print("University: ",University.uni_data['name'])
    print("Department: ",Departments.department1['name'])
    print("Teacher: ",Teacher.teacher1['name'])
    print("Teacher: ",Teacher.teacher1['subject'])
else:
    print("Student Fees: ", student1['Fees'])
    print("Student age: ", student1['age'])
    print("University: ", University.uni_data['name'])
    print("Department: ", Departments.department1['name'])
    print("Teacher: ", Teacher.teacher1['name'])
    print("Teacher: ", Teacher.teacher1['subject'])
