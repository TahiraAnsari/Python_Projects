uni_data={'name':'University of Sindh'}
