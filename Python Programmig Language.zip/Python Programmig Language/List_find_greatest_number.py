# write a python program to get the largest number from a list
my_List = [10,20,10,30,10,40]
largest = my_List[0]

for x in my_List:
    if x > largest:
        largest = x
print ('Largest Number is:',largest)

