def menu():
    print('\nMain Menu\n')
    print('1: Calculator')
    print('2: Marksheet')
    print('3: Odd & Even')
    print('4: Seasons')
    print('5: Leap Year')
    print('6: Student System')
    print('7: Teacher System')
    print('8: Bank System')
    print('9: Star Patterns')
    print('10: Exit')

    option = input('\nSelect any option:')

    if option == '1':
        calculator()
    elif option == '2':
        marksheet()
    elif option == '3':
        odd_even()
    elif option == '4':
        season()
    elif option == '5':
        leap_year()
    elif option == '6':
        student_system()
    elif option == '7':
        teacher_system()
    elif option == '8':
        bank_system()
    elif option == '9':
        star_pattern()
    elif option == '10':
        exit_system()

def calculator():
    print('\nCalulator')
    print('1: Addition')
    print('2: Subtraction')
    print('3: Multiplication')
    print('4: Division')
    print('5: Modulus')
    option = input('\nSelect any Arithmetic Function:')
    if option == '1':
        print('Addition')
        x = int(input('Enter first number:'))
        y = int(input('Enter second number:'))
        print('Addition is:',x+y)
        choice=input("\nDo you want to continue press 1 otherwise 0:")
        if choice=='1':
            calculator()
        else:
            menu()
        
    elif option =='2':
        print('Subtraction')
        x = int(input('Enter first number:'))
        y = int(input('Enter second number:'))
        print('Subtraction is:',x-y)
        choice=input("Do you want to continue press 1 otherwise 0:")
        if choice=='1':
            calculator()
        else:
            menu()

    elif option == '3':
        print('Multiplication')
        x = int(input('Enter first number:'))
        y = int(input('Enter second number:'))
        print('Multiplication is:',x*y)
        choice=input("Do you want to continue press 1 otherwise 0:")
        if choice=='1':
            calculator()
        else:
            menu()

    elif option == '4':
        print('Division')
        x = int(input('Enter first number:'))
        y = int(input('Enter second number:'))
        print('Division is:',x/y)
        choice=input("Do you want to continue press 1 otherwise 0:")
        if choice=='1':
            calculator()
        else:
            menu()

    elif option == '5':
        print('Modulus')
        x = int(input('Enter first number:'))
        y = int(input('Enter second number:'))
        print('Modulus is:',x%y)
        choice=input("Do you want to continue press 1 otherwise 0:")
        if choice=='1':
            calculator()
        else:
            menu()

def marksheet():
    print('\nMarksheet')
    print('Enter Personal Information\n')
    name = input('Enter your name:')
    Roll_no = input('Enter your Roll no:')
    print('\n')
    print('Enter your Subjects Marks')
    php = int(input('Enter your PHP Marks:'))
    java = int(input('Enter your Java Marks:'))
    python = int(input('Enter your Python Marks:'))
    total = 300
    print('Student Information\n')
    print('Full Name:',name)
    print('Roll no:',Roll_no)
    print('\n')
    print('Marks Information')
    obt = (php + java + python)
    print('Total Marks:',total)
    percentage = (obt*100)/total
    print('Obtained Marks:',obt)
    print('Percentage:',percentage)
    choice=input("\nDo you want to continue press 1 otherwise 0:")
    if choice=='1':
        marksheet()
    else:
        menu()


def odd_even():
    print('Odd & Even')
    number = int(input("Enter a number:"))
    if number % 2==0:
        print(number,"is a even number")
    else:
        print(number,"is a odd number")
    choice=input("\nDo you want to continue press 1 otherwise 0:")
    if choice=='1':
        odd_even()
    else:
        menu()

def season():
    print('Seasons')
    month =input("Enter month name:")

    if month=="december" or month=="january" or month=="febuary":
        print("Month name is:",month)
        print("Season is winter")
    elif month=="march" or month=="april" or month=="may":
        print("Month name is:",month)
        print("Season is Spring")
    elif month=="june" or month=="july" or month=="august":
        print("Month name is:",month)
        print("Season is Summer")
    elif month=="sepetmber" or month=="october" or month=="november":
        print("Month name is:",month)
        print("Season is Autumn")
    else:
        print("Invalid month name")
    choice=input("\nDo you want to continue press 1 otherwise 0:")
    if choice=='1':
        season()
    else:
        menu()

def leap_year():
    print('Leap Year')
    lp_Year = int(input('Enter Year:'))
    if lp_Year % 4 == 0:
        print(lp_Year,'is a Leap Year')
    else:
        print(lp_Year,'is not a Leap Year')
         
    choice=input("\nDo you want to continue press 1 otherwise 0:")
    if choice=='1':
        leap_year()
    else:
        menu()


def student_system():
    print('\nStudent System')
    def st_menu():
        print("Student Management System")
        print("Main Menu")
        print('1 View Student Record')
        print("2 Update Student Record")
        print("3 Add New Student Record")
        print("4 Delete Student Record")
        print("5 Exit System")

        option=input('\nSelect any option:')
        if option=='1':
            view()
        elif option=='2':
            update()
        elif option == '3':
            new_Student_Record()
        elif option == '4':
            delete_student_record()
        elif option == '5':
            exit_system()
        else:
            print('Invalid Input')

    def exit_system():
        print("Thank You Using Our System")
        print("System Exited")
        exit(0)

    def view():
        print("View Student Record")
        roll_no=input("Enter Student Roll_no")
        if roll_no==data[2]:
            for x in data:
                if x == 'ALi':
                    print('\nName:',x)
                elif x == '20000':
                    print('Fee is:',x)
                elif x == '20':
                    print('Roll_no:',x)
                elif x == 'IT':
                    print('Department:',x)
                elif x == 'USindh':
                    print('University:',x)
                elif x == 'ali@gmail.com':
                    print('Email',x)
            choice=input("\nDo you want to continue press 1 no press 0")
            if choice=='1':
                student_system()
            else:
                menu()
        else:
            print('Invalid Roll No')


    def update():
        print("Update Student Record")
        roll_no = input("Enter Student Roll No")
        if roll_no == data[2]:
            print(data)
            name =input("Enter Student New Name: ")
            data[0]=name
            print("Student Updated Record")
            print(data)
            choice = input("Do you want to continue press 1 no press 0")
            if choice == '1':
                student_system()
            else:
                menu()
        else:
            print('Invalid Roll No')
        

    def new_Student_Record():
        print('Add New Student Record')
        name = input('Enter Student Name:')
        data.append(name)
        roll_no = input('Enter Student Roll_no:')
        data.append(roll_no)
        fees = (input('Enter Student Fess:'))
        data.append(fees)
        university = input('Enter University Name:')
        data.append(university)
        deparment = input('Enter Department Name:')
        data.append(deparment)
        email = input('Enter Student Email id:')
        data.append(email)
        print('New Student Record Add:',data)
    
        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            student_system()
        else:
            menu()
    
    
    def delete_student_record():
        print('Delete Student Record:')
        choice = input('Do you want to Delete the Student Record(Y/N):')
        if choice == 'Y' or choice == 'y':
            data.clear()      
            print("Student data Delete:",data)
        else:
            print("you can't delete the Student data")

        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            student_system()
        else:
            menu()
        
    
        
    data =["ALi",'20000','20','IT','USindh','ali@gmail.com']
    option=0
    choice=0
    st_menu()



def teacher_system():
    print('Teacher System')
    def th_menu():
        print("Teacher Management System")
        print("Main Menu")
        print('1 View teacher Record')
        print("2 Update Teacher Record")
        print("3 Add New Teacher Record")
        print("4 Delete Teacher Record")
        print("5 Exit System")

        option=input('\nSelect any option:')
        if option=='1':
            view()
        elif option=='2':
            update()
        elif option == '3':
            new_teacher_Record()
        elif option == '4':
            delete_teacher_record()
        elif option == '5':
            exit_system()
        else:
            print('Invalid Input')

    def exit_system():
        print("Thank You Using Our System")
        print("System Exited")
        exit(0)

    def view():
        print("View Student Record")
        id=input("Enter Teacher ID:")
        if id==data[1]:
            for x in data:
                if x == 'ALi':
                    print('\nName:',x)
                elif x == '20':
                    print('Teacher ID:',x)
                elif x == 'IT':
                    print('Department:',x)
                elif x == 'University of Sindh':
                    print('University:',x)
                elif x == 'ali@gmail.com':
                    print('Email',x)
            choice=input("\nDo you want to continue press 1 no press 0")
            if choice=='1':
                teacher_system()
            else:
                menu()


    def update():
        print("Update Teacher Record")
        id = input("Enter Teacher ID:")
        if id == data[1]:
            print(data)
            name =input("Enter Teacher New Name: ")
            data[0]=name
            print("Teacher Updated Record")
            print(data)
            choice = input("Do you want to continue press 1 no press 0")
            if choice == '1':
                teacher_system()
            else:
                menu()
        

    def new_teacher_Record():
        print('Add New Teacher Record')
        name = input('Enter Student Name:')
        data.append(name)
        id = input('Enter Teacher ID:')
        data.append(roll_no)
        university = input('Enter University Name:')
        data.append(university)
        deparment = input('Enter Department Name:')
        data.append(deparment)
        email = input('Enter Teacher Email id:')
        data.append(email)
        print('New Teacher Record Add:',data)
    
        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            teacher_system()
        else:
            menu()
    
    
    def delete_teacher_record():
        print('Delete Teacher Record:')
        choice = input('Do you want to Delete the Student Record(Y/N):')
        if choice == 'Y' or choice == 'y':
            data.clear()      
            print("Teacher data Delete:",data)
        else:
            print("you can't delete the Teacher data")

        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            teacher_system()
        else:
            menu()
        
    
        
    data =["ALi",'01','IT','University of Sindh','ali@gmail.com']
    option=0
    choice=0
    th_menu()


def bank_system():
    print('Bank System')
    #Main Menu
    def bk_menu():
        print("Bank Management System")
        print("Main Menu")
        print('1 View Account Details')
        print("2 Deposit Amount")
        print("3 Withdraw Amount")
        print("4 Check Balance")
        print("5 Check History")
        print("6 Exit System")
    
        option=input('\nSelect any option: ')
        if option=='1':
            view_account_details()
        elif option=='2':
            deposit_amount()
        elif option == '3':
            withdraw_amount()
        elif option == '4':
            check_balance()
        elif option == '5':
            check_history()
        elif option == '6':
            exit_system()
        
    def exit_system():
        print("Thank You Using Our Banking System")
        print("System Exited")
        exit(0)
    
    def view_account_details():
        print('\nView Account Details')
        cnic = input("Enter CNIC no:")
        password = input('Enter your Password:')
        if cnic == acount[1] and password == 'p':
            for x in acount:
                if x == acount[0]:
                    print('\nName:',x)
                elif x == acount[1]:
                    print('CNIC no:',x)
                elif x == acount[2]:
                    print('District:',x)
                elif x == acount[3]:
                    print('Country:',x)
            
            choice=input("Do you want to continue press 1 no press 0:")
            if choice=='1':
                bank_system()
            else:
                menu()


#Deposit Amount
    def deposit_amount():
        print('\nDeposit Amount')
        cnic = input("Enter CNIC no:")
        password = input('Enter your Password:')
        if cnic == acount[1] and password == 'p':
            depositAmount = int(input('Enter your Amount'))
            sum = 0
            sum += depositAmount
            acount[4] += depositAmount
            depositList.append(depositAmount)
            print('Your are Deposite',sum,'Amount')
        choice=input("Do you want to continue press 1 no press 0:")
        if choice=='1':
            bank_system()
        else:
            menu()
        

# Withdraw Amount
    def withdraw_amount():
        print('\nWithdraw Amount')
        cnic = input("Enter CNIC no:")
        password = input('Enter your Password:')
        if cnic == acount[1] and password == 'p':
            withdraw = int(input("Withdraw your Amount:"))
            if withdraw <= acount[4]:
                print('Your Withdraw is',withdraw)
                acount[4] -= withdraw
                print('Current balnce is:',acount[4])
            elif withdraw >= acount[4]:
                print('Invalid Withdarw',withdraw,"because in your acount you have can't this much amount.")
            elif acount[4] != withdraw:
                print('Account is Empty')
        
        choice=input("Do you want to continue press 1 no press 0:")
        if choice=='1':
            bank_system()
        else:
            menu()
        
# Check Balance
    def check_balance():
        cnic = input("Enter CNIC no:")
        password = input('Enter your Password:')
        if cnic == acount[1] and password == 'p':
            print('\nCheck Balance')
            print('Your Current balance is:',acount[4])

        choice=input("Do you want to continue press 1 no press 0:")
        if choice=='1':
            bank_system()
        else:
            menu()

# Check History
    def check_history():
        cnic = input("Enter CNIC no:")
        password = input('Enter your Password:')
        if cnic == acount[1] and password == 'p':
            print('Check History')
            for x in depositList:
                print('Your Deposite History is:',x)
        
        choice=input("Do you want to continue press 1 no press 0:")
        if choice=='1':
            bank_system()
        else:
            menu()



    acount = ["ALi",'41','Hyderabad','Pakistan',2000]
    depositList = []
    password = 'p'
    choice = 0
    option = 0
    bk_menu()



def star_pattern():
    print('Star Pattern')
    for x in range(1,6):
        print("*" * x)
    choice=input("Do you want to continue press 1 no press 0:")
    if choice=='1':
        star_pattern()
    else:
        menu()

def exit_system():
    print("Thank You Using Our Banking System")
    print("System Exited")
    exit(0)

option = 0
choice = 0
menu()
    
    
