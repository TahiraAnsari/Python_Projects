# Assignment: 07
# 1
# 12
# 123
# 1234
# 12345

for a in range(1, 6):
    for b in range(1,a+1):
        print(b, end = '')
    print()


