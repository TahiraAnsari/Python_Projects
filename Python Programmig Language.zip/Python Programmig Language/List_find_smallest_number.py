# write a python program to get the Smallest number from a list

my_List = [10,20,10,30,10]
smallest = my_List[0]
for x in my_List:
    if x < smallest:
        smallest = x
print ('Smallest Number is:',smallest)
