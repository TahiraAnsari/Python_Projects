# write python program to sum all values of list
# List = [10,20,10,30,10]
# Sum of list value: 80


my_List = [10,20,10,30,10]
sum = 0
for num in my_List:
    sum += num
print("Sum of list value:",sum)
