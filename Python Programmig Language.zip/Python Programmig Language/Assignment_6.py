 # Assignment: 06
 # *
 # **
 # ***
 # ****
 # *****
 
for x in range(1,6):
    print("*" * x)

