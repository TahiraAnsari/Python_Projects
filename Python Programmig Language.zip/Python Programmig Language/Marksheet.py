print('------------ Marksheet ---------------')
print('Enter Personal Information')
print('***************************')
name = input('Enter your name: ')
Roll_no = input('Enter your Roll no: ')
print('\n')
print(' Enter your Subjects Marks')
print('****************************')
php = int(input('Enter your PHP Marks:'))
java = int(input('Enter your Java Marks:'))
python = int(input('Enter your Python Marks:'))
total = 300
print('\n')
print('Student Information')
print('**********************')
print('Full Name:',name)
print('Roll no:',Roll_no)
print('\n')
print('Marks Information')
print('**********************')
obt = (php + java + python)
print('Total Marks:',total)
percentage = (obt*100)/total
print('Obtained Marks:',obt)
print('Percentage:',percentage)



