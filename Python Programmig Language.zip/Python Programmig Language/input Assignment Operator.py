# Assignment Operator
x = int(input('Enter a Number: '))

print('\n -----------Assignment Operator---------')
add = int(input('ADD in previous Value: '))
x += add
print('Addition Value: ',x)

print('\n')
sub = int(input('Subtract in previous Value: '))
x -= sub
print('Subtracted Value: ',x)

print('\n')
div = int(input('Divide in previous Value:'))
x /= div
print('Divided Value: ',x)

print('\n')
mul = int(input('Multiply in previous Value: '))
x *= mul
print('Multiplicated Value: ',x)

