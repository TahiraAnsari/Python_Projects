# Assignment: 08
# 1
# 2
# 2
# 2
# 3
# 2
# 4
# 2
# 5
# 2

for d in range (1,6):
    print(d)
    print(2)
