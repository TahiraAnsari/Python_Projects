def menu():
    print("Student Management System")
    print("Main Menu/Functions")
    print('1 View Student Record')
    print("2 Update Student Record")
    print("3 Add New Student Record")
    print("4 Delete Student Record")
    print("5 Exit System")
    
    option=input('Select any option: ')
    if option=='1':
        view()
    elif option=='2':
        update()
    elif option == '3':
        new_Student_Record()
    elif option == '4':
        delete_student_record()
    elif option == '5':
        exit_system()
    else:
        print('Invalid Input')
        
def exit_system():
    print("Thank You Using Our System")
    print("System Exited")
    exit(0)

def view():
    print("View Student Record")
    roll_no=input("Enter Student Roll No")
    if roll_no==data[2]:
        print(data)
        choice=input("Do you want to continue press 1 no press 0")
        if choice=='1':
            menu()
        else:
            exit_system()
    else:
        print('Invalid Roll No')


def update():
    print("Update Student Record")
    roll_no = input("Enter Student Roll No")
    if roll_no == data[2]:
        print(data)
        name =input("Enter Student New Name: ")
        data[0]=name
        print("Student Updated Record")
        print(data)
        choice = input("Do you want to continue press 1 no press 0")
        if choice == '1':
            menu()
        else:
            exit_system()
    else:
        print('Invalid Roll No')
        

def new_Student_Record():
    print('Add New Student Record')
    name = input('Enter Student Name:')
    data.append(name)
    roll_no = input('Enter Student Roll_no:')
    data.append(roll_no)
    fees = (input('Enter Student Fess:'))
    data.append(fees)
    university = input('Enter University Name:')
    data.append(university)
    deparment = input('Enter Department Name:')
    data.append(deparment)
    email = input('Enter Student Email id:')
    data.append(email)
    print('New Student Record Add:',data)
    
    choice = input("Do you want to continue press 1 no press 0")
    if choice == '1':
        menu()
    else:
        exit_system()
    
    
def delete_student_record():
    print('Delete Student Record:')
    choice = input('Do you want to Delete the Student Record(Y/N):')
    if choice == 'Y' or choice == 'y':
        data.clear()      
        print("Student data Delete:",data)
    else:
        print("you can't delete the Student data")

    choice = input("Do you want to continue press 1 no press 0")
    if choice == '1':
        menu()
    else:
        exit_system()
        
    
        
data =["ALi",'20000','20','IT','USindh','ali@gmail.com']
option=0
choice=0
menu()
