x = 10
y = 20
z = 30
print('x value is:' ,x , '\n', 'y value is:' ,y, '\n', 'z value is:' ,z)
x += 5
y += 5
z += 5
print('\n', 'When we Add: 5 in the x y and z, now the result is:')
print('\n', 'x value is:' ,x , '\n', 'y value is:' ,y, '\n', 'z value is:' ,z)
x -= 2
y -= 2
z -= 2
print('\n', 'When we Subtrat: 2 in the x y and z, now the result is:')
print('\n', 'x value is:' ,x , '\n', 'y value is:' ,y, '\n', 'z value is:' ,z)
x *= 10
y *= 10
z *= 10
print('\n', 'When we Multiple: 10 in the x y and z, now the result is:')
print('\n', 'x value is:' ,x , '\n', 'y value is:' ,y, '\n', 'z value is:' ,z)
x /= 5
y /= 5
z /= 5
print('\n', 'When we Divide: 5 in the x y and z, now the result is:')
print('\n', 'x value is:' ,x , '\n', 'y value is:' ,y, '\n', 'z value is:' ,z)
