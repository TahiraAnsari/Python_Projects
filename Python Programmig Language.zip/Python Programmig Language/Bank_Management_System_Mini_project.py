#Main Menu
def menu():
    print("Bank Management System")
    print("Main Menu")
    print('1 View Account Details')
    print("2 Deposit Amount")
    print("3 Withdraw Amount")
    print("4 Check Balance")
    print("5 Check History")
    print("6 Exit System")
    
    option=input('\nSelect any option: ')
    if option=='1':
        view_account_details()
    elif option=='2':
        deposit_amount()
    elif option == '3':
        withdraw_amount()
    elif option == '4':
        check_balance()
    elif option == '5':
        check_history()
    elif option == '6':
        exit_system()
        
# Exit from System
def exit_system():
    print("Thank You Using Our Banking System")
    print("System Exited")
    exit(0)
    
# View Account Details
def view_account_details():
    print('\nView Account Details')
    cnic = input("Enter CNIC no:")
    password = input('Enter your Password:')
    if cnic == acount[1] and password == 'p':
        for x in acount:
            if x == acount[0]:
                print('\nName:',x)
            elif x == acount[1]:
                print('CNIC no:',x)
            elif x == acount[2]:
                print('District:',x)
            elif x == acount[3]:
                print('Country:',x)
            
        choice=input("Do you want to continue press 1 no press 0:")
        if choice=='1':
            menu()
        else:
            exit_system()


#Deposit Amount
def deposit_amount():
    print('\nDeposit Amount')
    cnic = input("Enter CNIC no:")
    password = input('Enter your Password:')
    if cnic == acount[1] and password == 'p':
        depositAmount = int(input('Enter your Amount'))
        sum = 0
        sum += depositAmount
        acount[4] += depositAmount
        depositList.append(depositAmount)
        print('Your are Deposite',sum,'Amount')
    choice=input("Do you want to continue press 1 no press 0:")
    if choice=='1':
        menu()
    else:
        exit_system()
        

# Withdraw Amount
def withdraw_amount():
    print('\nWithdraw Amount')
    cnic = input("Enter CNIC no:")
    password = input('Enter your Password:')
    if cnic == acount[1] and password == 'p':
        withdraw = int(input("Withdraw your Amount:"))
        if withdraw <= acount[4]:
            print('Your Withdraw is',withdraw)
            acount[4] -= withdraw
            print('Current balnce is:',acount[4])
        elif withdraw >= acount[4]:
            print('Invalid Withdarw',withdraw,"because in your acount you have can't this much amount.")
        elif acount[4] != withdraw:
            print('Account is Empty')
        
    choice=input("Do you want to continue press 1 no press 0:")
    if choice=='1':
        menu()

    else:
        exit_system()
        
# Check Balance
def check_balance():
    cnic = input("Enter CNIC no:")
    password = input('Enter your Password:')
    if cnic == acount[1] and password == 'p':
        print('\nCheck Balance')
        print('Your Current balance is:',acount[4])

    choice=input("Do you want to continue press 1 no press 0:")
    if choice=='1':
        menu()
    else:
        exit_system()

# Check History
def check_history():
    cnic = input("Enter CNIC no:")
    password = input('Enter your Password:')
    if cnic == acount[1] and password == 'p':
        print('Check History')
        for x in depositList:
            print('Your Deposite History is:',x)
        
    choice=input("Do you want to continue press 1 no press 0:")
    if choice=='1':
        menu()
    else:
        exit_system()



acount = ["ALi",'41','Hyderabad','Pakistan',2000]
depositList = []
password = 'p'
choice = 0
option = 0
menu()

