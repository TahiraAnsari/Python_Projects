# 5: Write a python program to display the multiplication table of a given
# integer.
# Test Data
# Input the number(Table to be calculated): Input number of terms: 5
# Expected Output
# 5 x  0 = 0
# 5 x  1 = 5
# 5 x  2 = 10 
# 5 x  3 = 15

table = int(input('Enter a Table number:'))


print(table,'X ',0 ,' =', table * 0)
print(table,'X ',1 ,' =', table * 1)
print(table,'X ',2 ,' =', table * 2)
print(table,'X ',3 ,' =', table * 3)
print(table,'X ',4 ,' =', table * 4)
print(table,'X ',5 ,' =', table * 5)
print(table,'X ',6 ,' =', table * 6)
print(table,'X ',7 ,' =', table * 7)
print(table,'X ',8 ,' =', table * 8)
print(table,'X ',9 ,' =', table * 9)
print(table,'X ',10 ,' =', table * 10)
